package zad2;

public enum TaskState {
	CREATED,
	RUNNING,
	READY,
	ABORTED;
}
